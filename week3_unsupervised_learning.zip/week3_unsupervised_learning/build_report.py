"""Builds reports/week3_internship_report.pdf from outputs/results/results.json (numbers always match the code run)."""

import json, os
import pandas as pd
from PIL import Image as PILImage
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle, Image, KeepTogether)

HERE = os.path.dirname(os.path.abspath(__file__)); os.chdir(HERE)
R = json.load(open("outputs/results/results.json"))
VIS, RES = "outputs/visualizations", "outputs/results"
os.makedirs("reports", exist_ok=True)

ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["Normal"], fontName="Helvetica", fontSize=9.6, leading=13.6, alignment=TA_JUSTIFY, spaceAfter=5)
H1 = ParagraphStyle("h1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=14.5, textColor=colors.HexColor("#1F3A5F"), spaceBefore=10, spaceAfter=6, keepWithNext=1)
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=11, textColor=colors.HexColor("#2E5C8A"), spaceBefore=6, spaceAfter=4, keepWithNext=1)
CAP = ParagraphStyle("cap", parent=BODY, fontSize=8.2, leading=10.5, textColor=colors.HexColor("#444444"), alignment=TA_CENTER, spaceAfter=8)
CELL = ParagraphStyle("cell", parent=BODY, fontSize=7.8, leading=9.6, alignment=0, spaceAfter=0)
CELLB = ParagraphStyle("cellb", parent=CELL, fontName="Helvetica-Bold")
CODE = ParagraphStyle("code", parent=BODY, fontName="Courier", fontSize=8.2, leading=10.5, alignment=0, backColor=colors.HexColor("#F3F5F8"), borderPadding=4, spaceAfter=7)
BUL = ParagraphStyle("bul", parent=BODY, leftIndent=14, bulletIndent=4, spaceAfter=2.5)

S = []
def h1(t): S.append(Paragraph(t, H1))
def h2(t): S.append(Paragraph(t, H2))
def p(t): S.append(Paragraph(t, BODY))
def code(t): S.append(Paragraph(t.replace("\n", "<br/>").replace(" ", "&nbsp;"), CODE))
def bullets(items):
    for it in items: S.append(Paragraph(it, BUL, bulletText="-"))
def sp(h=6): S.append(Spacer(1, h))

def fig(name, caption, w=16.2):
    path = f"{VIS}/{name}"; iw, ih = PILImage.open(path).size
    S.append(KeepTogether([Image(path, width=w * cm, height=w * cm * ih / iw), Paragraph(caption, CAP)]))

def table(rows, widths=None, header=True, fs=None):
    data = [[Paragraph(str(c), CELLB if (header and i == 0) else CELL) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=[w * cm for w in widths] if widths else None, repeatRows=1 if header else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#B8C2CC")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
          ("TOPPADDING", (0, 0), (-1, -1), 2.5), ("BOTTOMPADDING", (0, 0), (-1, -1), 2.5)]
    if header: st += [("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DCE6F2"))]
    t.setStyle(TableStyle(st)); S.append(KeepTogether([t]) if len(rows) <= 16 else t); sp(8)

def df_table(df, widths=None, fmt=4):
    rows = [list(df.columns)] + [[(f"{v:.{fmt}f}" if isinstance(v, float) else str(v)) for v in r] for r in df.values.tolist()]
    table(rows, widths)

f4 = lambda v: f"{v:.4f}"
km, hc, pc, cv = R["kmeans_final"], R["hier_final"], R["pca"], R["cv"]
K = km["K"]
cls = pd.DataFrame(R["classification"]["table"]); dt = pd.DataFrame(R["dtree_tuning"]["table"])
sw = pd.DataFrame(R["kmeans_sweep"]["table"])
wk = R["worked_metrics"]

# ============================ COVER ============================
S.append(Spacer(1, 4.5 * cm))
S.append(Paragraph("Week 3 Internship Report", ParagraphStyle("t0", parent=H1, fontSize=24, alignment=TA_CENTER, textColor=colors.HexColor("#1F3A5F"))))
S.append(Paragraph("Unsupervised Learning and Model Evaluation", ParagraphStyle("t1", parent=H1, fontSize=17, alignment=TA_CENTER)))
sp(18)
S.append(Paragraph("K-Means and Hierarchical Clustering, PCA, Cross-Validation, Confusion Matrix, Precision/Recall/F1, ROC-AUC and Hyperparameter Tuning",
                   ParagraphStyle("t2", parent=BODY, alignment=TA_CENTER, fontSize=11, leading=15)))
sp(50)
table([["Intern", "Pranav Y"], ["Programme", "AI/ML Internship - Week 3"], ["Institution", "Erode Sengunthar Engineering College (B.E. Computer Science and Engineering)"],
       ["Datasets", "Wine (clustering, n=178) and Breast Cancer Wisconsin (supervised evaluation, n=569), both built into Scikit-learn"],
       ["Language / Libraries", "Python, NumPy, Pandas, Matplotlib, Seaborn, Scikit-learn, SciPy"], ["Reproducibility", "random_state = 42 throughout; run `python run_all.py`"]],
      widths=[4, 12], header=False)
S.append(PageBreak())

# ============================ ABSTRACT ============================
h1("1. Abstract")
p(f"This report applies unsupervised learning and standard model-evaluation techniques to real data and reports only values produced by executed code. "
  f"Part A clusters the Wine dataset (178 samples, 13 chemical features) without using its class labels. K-Means was evaluated for k = 2 to 10; the silhouette score, "
  f"Davies-Bouldin index and the elbow of the inertia curve all selected k = {K} (inertia {km['inertia']:.1f}, silhouette {f4(km['metrics']['silhouette'])}). "
  f"Ward hierarchical clustering with k = {K} reached a silhouette of {f4(hc['metrics']['silhouette'])}; the two methods agreed with an Adjusted Rand Index (ARI) of {f4(R['comparison']['agreement_ARI'])}. "
  f"As a post-hoc check only, K-Means recovered the true wine classes with ARI = {f4(km['external_posthoc']['ARI'])} versus {f4(hc['external_posthoc']['ARI'])} for Ward. "
  f"PCA showed that {pc['n80']} of 13 components retain 80% of the variance and that the first two retain {pc['cum'][1]*100:.1f}%.")
p(f"Part B evaluates supervised classifiers on the Breast Cancer dataset (malignant = positive class): stratified 5-fold cross-validation of a Logistic Regression pipeline gave a mean ROC-AUC of "
  f"{cv['mean']['roc_auc']:.4f} (std {cv['std']['roc_auc']:.4f}); on a held-out test set the tuned Logistic Regression reached precision {wk['precision']:.4f}, recall {wk['recall']:.4f}, F1 {wk['f1']:.4f} "
  f"and ROC-AUC {cls.loc[1,'roc_auc']:.4f}. Hyperparameter tuning produced no gain for Logistic Regression or Random Forest (their defaults were already near-optimal) but improved the cross-validated AUC of an overfitting "
  f"Decision Tree from {dt.loc[0,'CV_ROC_AUC(train)']:.4f} to {dt.loc[1,'CV_ROC_AUC(train)']:.4f}, while lowering its thresholded recall - a trade-off analysed in Section 21.")

h1("2. Introduction")
p("Supervised learning (Week 2) needs labelled examples. Unsupervised learning discovers structure in unlabelled data, and its quality cannot be measured with accuracy or a confusion matrix. "
  "This report therefore keeps two evaluation tracks strictly separate: clustering is judged by internal metrics (silhouette, Davies-Bouldin, Calinski-Harabasz) and by stability, while classification "
  "is judged by cross-validation, the confusion matrix, precision, recall, F1 and ROC-AUC. The two families of metrics are never placed in the same comparison table.")
p("The two previous submissions were reviewed as well-structured but lacking numerical evidence. Every section below therefore follows the pattern INPUT - FORMULA - CALCULATION - OUTPUT - INTERPRETATION wherever a calculation is shown.")

h1("3. Internship Task Objectives")
bullets(["Implement K-Means and Hierarchical (agglomerative) clustering and understand dimensionality reduction with PCA.",
         "Demonstrate cross-validation, confusion matrix, precision, recall, F1-score, ROC-AUC and hyperparameter tuning.",
         "Deliverable: perform clustering on a dataset and prepare a professional Model Evaluation Report."])
h1("4. Tools and Technologies")
table([["Tool", "Purpose"], ["Python 3, VS Code / Jupyter", "Implementation environment"], ["NumPy, Pandas", "Numerical computation, tabular data"],
       ["Matplotlib, Seaborn", "All visualisations"], ["Scikit-learn", "KMeans, AgglomerativeClustering, PCA, StandardScaler, Pipeline, cross-validation, GridSearchCV, RandomizedSearchCV, metrics"],
       ["SciPy", "Linkage matrix, dendrogram, cophenetic correlation"]], widths=[5, 11])

# ============================ DATA ============================
h1("5. Dataset Description")
p("Part A uses the Wine dataset (UCI, shipped with Scikit-learn): chemical analysis of wines grown in one Italian region from three cultivars. It suits clustering because it has 13 continuous features on very different "
  "scales (which makes scaling essential), correlated features (which makes PCA meaningful) and genuine labels that can be used only afterwards, as an honest external check. Part B uses the Breast Cancer Wisconsin "
  "dataset because it is a clean binary problem suited to confusion-matrix and ROC analysis; it was also used in Week 2.")
h1("6. Dataset Understanding")
table([["Property", "Wine (clustering)", "Breast Cancer (classification)"], ["Records", "178", f"{R['bc_data']['n']}"], ["Features", "13 (all float64)", f"{R['bc_data']['features']} (all numeric)"],
       ["Missing values", "0 (0.00%)", "0"], ["Duplicate rows", "0", "-"], ["Categorical variables", "0 (no encoding needed)", "0"],
       ["Labels", "3 classes: 59 / 71 / 48 - NOT used for clustering", f"malignant {R['bc_data']['malignant']} (37.3%), benign {R['bc_data']['benign']}"]], widths=[4, 6, 6])
p("All 13 Wine features were used for clustering: alcohol, malic_acid, ash, alcalinity_of_ash, magnesium, total_phenols, flavanoids, nonflavanoid_phenols, proanthocyanins, color_intensity, hue, "
  "od280/od315_of_diluted_wines and proline. No target column was passed to any clustering or PCA call.")

# ============================ EDA ============================
h1("7. Exploratory Data Analysis")
eda = pd.read_csv(f"{RES}/eda_summary_statistics.csv", index_col=0).round(3)
eda = eda[["mean", "median", "std", "min", "max", "skew"]].reset_index().rename(columns={"index": "feature"})
df_table(eda, widths=[4.6, 2, 2, 2, 2, 2, 1.8], fmt=3)
fig("01_histograms.png", "Figure 1. Distributions of all 13 features with kernel density estimates and skewness.", w=13.5)
p("<b>Interpretation.</b> Feature scales differ enormously: proline spans 278 to 1680 (std 314.9) whereas hue spans 0.48 to 1.71 (std 0.229), a ratio of roughly 1,400 in standard deviation. "
  "magnesium (skew 1.10), malic_acid (1.04) and color_intensity (0.87) are right-skewed; for malic_acid the mean (2.336) exceeds the median (1.865), confirming a long upper tail. alcohol, flavanoids and hue are nearly symmetric (skew within +/-0.06).")
fig("02_boxplots.png", "Figure 2. Box plots of standardised features. Dots mark values outside 1.5 x IQR.", w=15)
p("<b>Outliers.</b> The IQR rule flags 21 values across 7 features (magnesium 4, color_intensity 4, alcalinity_of_ash 4, ash 3, malic_acid 3, proanthocyanins 2, hue 1), affecting 17 of 178 rows (9.6%). "
  "They are plausible chemical measurements rather than errors and the dataset is small, so they were retained.")
fig("03_correlation_heatmap.png", "Figure 3. Pearson correlation matrix.", w=13.5)
p("<b>Correlation.</b> The strongest pairs are total_phenols-flavanoids (r = 0.865), flavanoids-od280/od315 (0.787), total_phenols-od280/od315 (0.700), flavanoids-proanthocyanins (0.653) and alcohol-proline (0.644). "
  "Several features carry overlapping information, which predicts that a few principal components will capture most of the variance (confirmed in Section 16).")
fig("04_pairplot.png", "Figure 4. Pair plot of four key features. Colour shows the true class and is for interpretation only - clustering never saw it.", w=13.5)
h1("8. EDA Findings")
bullets(["Three visually separable groups exist in flavanoids vs proline and flavanoids vs color_intensity; two groups (classes 1 and 2) overlap in proline and alcohol, so some misassignment is expected.",
         "Without scaling, distance-based clustering would be dominated by proline and magnesium (Section 9, worked example 2).",
         "High feature correlation justifies testing PCA before clustering; moderate right-skew does not require transformation for K-Means or Ward.",
         "No cleaning (imputation, de-duplication, encoding) was required; outliers were investigated and kept."])

h1("9. Data Preprocessing")
p("Z-score standardisation was applied to every feature: z = (x - mean) / std, giving mean 0 and standard deviation 1. Scaling matters because K-Means and Ward linkage use Euclidean distance, so a feature measured in the hundreds would outweigh one measured in fractions.")
p("<b>Worked example 1 - z-score.</b> INPUT: sample 0, proline x = 1065, mean = 746.893, std = 314.022. FORMULA: z = (x - mean)/std. CALCULATION: (1065 - 746.893)/314.022 = 1.0130. OUTPUT: scikit-learn gives 1.0130. "
  "INTERPRETATION: this wine's proline is about one standard deviation above average.")
p("<b>Worked example 2 - why scaling matters.</b> For samples 0 and 1 the raw Euclidean distance is 31.265, and magnesium alone supplies 74.58% of the squared distance (proline 23.02%). After standardisation the distance is 3.498, "
  "magnesium's share falls to 29.38% and proline's to 0.02%. INTERPRETATION: before scaling, two features decide almost everything; afterwards all 13 contribute.")
fig("05_scale_before_after.png", "Figure 5. Standard deviation per feature before (log axis) and after standardisation.", w=14.5)
p("Because clustering has no test set, the scaler was fitted on the full feature matrix; for the supervised experiments the scaler sits inside a Pipeline and is fitted only on training folds to avoid data leakage.")

# ============================ KMEANS ============================
h1("10. K-Means Clustering Implementation")
p("K-Means starts with k centroids (here chosen by k-means++), assigns every observation to its nearest centroid by Euclidean distance, recomputes each centroid as the mean of its members, and repeats until assignments stop changing. "
  "Inertia (within-cluster sum of squares) is the sum of squared distances from each point to its centroid; it always falls as k grows, so it cannot be minimised blindly.")
w = R["kmeans_worked_example"]
p(f"<b>Worked example - assignment.</b> INPUT: standardised sample {w['sample']} and the three fitted centroids. FORMULA: d = sqrt(sum((x - c)^2)). OUTPUT: distances = {w['distances']}. INTERPRETATION: the smallest distance is "
  f"{min(w['distances']):.3f}, so the sample is assigned to cluster {w['assigned']}.")
h1("11. Elbow Method Analysis")
t = [["k", "Inertia", "Drop vs previous (%)", "Silhouette", "Davies-Bouldin", "Calinski-Harabasz"]]
for r in R["kmeans_sweep"]["table"]:
    drop = "-" if pd.isna(r.get("inertia_drop_%")) else f"{r['inertia_drop_%']:.2f}"
    t.append([r["k"], f"{r['inertia']:.2f}", drop, f4(r["silhouette"]), f4(r["davies_bouldin"]), f"{r['calinski_harabasz']:.2f}"])
table(t, widths=[1.2, 2.6, 3.4, 2.6, 3, 3.2])
fig("06_elbow_silhouette_db.png", "Figure 6. Elbow curve, silhouette score and Davies-Bouldin index for k = 2 to 10 (dashed line = selected k).")
p(f"<b>Decision.</b> Inertia falls by 22.96% from k=2 to k=3, then only 8.02%, 5.61%, 5.72% ... for later steps: the bend is at k=3 (largest second difference of the inertia curve). "
  f"The silhouette is highest at k=3 ({sw.loc[1,'silhouette']:.4f}) and the Davies-Bouldin index is lowest at k=3 ({sw.loc[1,'davies_bouldin']:.4f}). Three independent criteria agree, so K = {K}. "
  "The absolute silhouette (0.28) is modest: it indicates real but overlapping structure, not sharply separated clusters.")
h2("Final K-Means model")
sz = ", ".join(f"cluster {i}: {s} ({pcn:.2f}%)" for i, (s, pcn) in enumerate(zip(km["sizes"], km["percents"])))
p(f"Fitted with k={K}, init=k-means++, n_init=10, random_state=42; converged in {km['n_iter']} iterations. Inertia = {km['inertia']:.3f}; silhouette = {f4(km['metrics']['silhouette'])}; "
  f"Davies-Bouldin = {f4(km['metrics']['davies_bouldin'])}; Calinski-Harabasz = {km['metrics']['calinski_harabasz']:.2f}. Cluster sizes: {sz}.")
fig("07_kmeans_silhouette_plot.png", "Figure 7. Per-sample silhouette values by cluster. Samples near or below zero lie at cluster borders.", w=11.5)
cent = pd.read_csv(f"{RES}/kmeans_centroids_original_units.csv", index_col=0).T.reset_index().rename(columns={"index": "feature"})
cent.columns = ["feature"] + [f"cluster {c}" for c in cent.columns[1:]]
df_table(cent, widths=[5.5, 3, 3, 3], fmt=3)
fig("08_kmeans_centroid_heatmap.png", "Figure 8. Cluster centroids in standardised units (red = above average, blue = below).", w=15)
p("<b>Cluster interpretation.</b> Cluster 0 (65 wines): low alcohol (12.25), low color_intensity (2.97), proline 510 - light, low-alcohol wines. Cluster 1 (51): highest malic_acid (3.31) and color_intensity (7.24) with very low flavanoids (0.82) and hue (0.69). "
  "Cluster 2 (62): highest proline (1100), alcohol (13.68) and flavanoids (3.00) - full-bodied, phenol-rich wines.")
h2("Post-hoc external check (labels used only after clustering)")
ct = pd.DataFrame(km["crosstab"], index=["class 0", "class 1", "class 2"], columns=["cluster 0", "cluster 1", "cluster 2"]).reset_index().rename(columns={"index": "true class"})
df_table(ct, widths=[3, 3, 3, 3], fmt=0)
p(f"ARI = {f4(km['external_posthoc']['ARI'])}, NMI = {f4(km['external_posthoc']['NMI'])}, homogeneity = {f4(km['external_posthoc']['homogeneity'])}. "
  "True class 0 maps to cluster 2 (59 of 59), class 2 to cluster 1 (48 of 48) and class 1 to cluster 0 (65 of 71); only 6 of 178 wines (3.4%) fall outside their majority cluster. "
  "External metrics are legitimate here only because genuine ground-truth labels exist; they would not be available in a real unlabelled problem.")
h2("Stability under resampling (clustering analogue of cross-validation)")
st = R["kmeans_stability"]
p(f"K-Means was re-fitted on 50 random 80% subsamples and each model labelled all 178 points; agreement with the full-data clustering had mean ARI = {st['mean']:.4f} (std {st['std']:.4f}, min {st['min']:.4f}, max {st['max']:.4f}). "
  "Consequently the three-cluster solution is stable.")
fig("09_kmeans_stability.png", "Figure 9. Distribution of ARI across 50 resamples.", w=9.5)

# ============================ HIERARCHICAL ============================
h1("12. Hierarchical Clustering Implementation")
p("Agglomerative clustering starts with every sample as its own cluster and repeatedly merges the two closest clusters until one remains. The linkage method defines cluster-to-cluster distance: Ward merges the pair that least "
  "increases within-cluster variance (Euclidean only); complete uses the maximum pairwise distance; average the mean pairwise distance; single the minimum.")
h1("13. Dendrogram Analysis")
dd = R["dendrogram"]
fig("10_dendrogram_ward.png", f"Figure 10. Ward dendrogram (truncated to 30 leaves). Dashed line: cut at height {dd['cut_k3']:.2f}, giving k = 3.")
p(f"<b>Reading the dendrogram.</b> The height of a join is the Ward distance at which two clusters merge; a tall vertical line means dissimilar clusters were forced together. The last merge heights are {dd['last_heights']}. "
  f"The jump from 12.567 (4 to 3 clusters) to 27.652 (3 to 2 clusters) is 15.085 - far larger than any earlier gap (all below 1.0) - so cutting between those heights, at {dd['cut_k3']:.2f}, yields three well-separated clusters.")
ws = pd.DataFrame(R["ward_sweep"])
df_table(ws.rename(columns={"davies_bouldin": "Davies-Bouldin", "calinski_harabasz": "Calinski-Harabasz", "silhouette": "Silhouette"}), widths=[2, 3.5, 3.5, 4])
p(f"Ward silhouette peaks at k = {hc['k_ward_best_silhouette']} ({ws.loc[1,'silhouette']:.4f}), consistent with the dendrogram.")
h2("Linkage and distance-metric comparison (k = 3)")
lc = pd.DataFrame(R["linkage_comparison"])
lc["sizes"] = lc["sizes"].astype(str)
df_table(lc.rename(columns={"cophenetic_corr": "Cophenetic r", "silhouette": "Silhouette", "davies_bouldin": "DB", "calinski_harabasz": "CH", "ARI_vs_true_posthoc": "ARI (post-hoc)"}),
         widths=[2, 2.2, 2.2, 1.8, 2, 3, 2.6], fmt=4)
p("<b>Interpretation.</b> Ward is clearly best in this experiment (silhouette 0.2774, CH 67.6, ARI 0.7899). Average and single linkage produced degenerate partitions of sizes [174, 3, 1]: they chain together and treat outliers as clusters. "
  "Their Davies-Bouldin values (1.03 and 0.91) look 'better' than Ward's 1.42 only because tiny clusters are compact - a warning that no single internal metric should be trusted alone; their CH (about 4) and silhouette (0.16-0.18) expose the failure.")
mc = pd.DataFrame(R["metric_comparison"])
df_table(mc.rename(columns={"silhouette": "Silhouette", "davies_bouldin": "DB", "calinski_harabasz": "CH"}), widths=[3, 3, 3, 3, 3])
p("Ward linkage is mathematically defined only for Euclidean distance, so it was not combined with other metrics. For complete and average linkage, cosine distance gave the best silhouette (0.2443 and 0.2645) but both remain below Ward-Euclidean (0.2774).")

h1("14. K-Means vs Hierarchical Comparison")
cmp_df = pd.read_csv(f"{RES}/clustering_comparison.csv")
df_table(cmp_df, widths=[5.5, 4.5, 5], fmt=4)
ctc = pd.DataFrame(R["comparison"]["crosstab"], index=["K-Means 0", "K-Means 1", "K-Means 2"], columns=["Ward 0", "Ward 1", "Ward 2"]).reset_index().rename(columns={"index": ""})
df_table(ctc, widths=[3.5, 3, 3, 3], fmt=0)
p(f"<b>Findings.</b> (1) K-Means produced slightly better-separated clusters on every internal metric (silhouette 0.2849 vs 0.2774, Davies-Bouldin 1.3892 vs 1.4186, CH 70.94 vs 67.65), though the differences are small. "
  f"(2) The assignments are similar (ARI between methods = {R['comparison']['agreement_ARI']:.4f}); 169 of 178 wines (94.9%) were grouped consistently. (3) Sizes differ moderately: [65, 51, 62] vs [58, 56, 64]. "
  "(4) Against the true classes, K-Means (ARI 0.8975) beat Ward (0.7899). (5) For this compact, roughly spherical, standardised dataset K-Means is the more appropriate method; the dendrogram, however, gave additional evidence for k = 3 that K-Means alone cannot provide. "
  "These conclusions apply to this dataset only; hierarchical clustering is preferable when nested structure matters or clusters are non-spherical.")

# ============================ PCA ============================
h1("15. K-Means Hyperparameter Tuning")
kt = pd.DataFrame(R["kmeans_tuning"])[["init", "n_init", "inertia_mean", "inertia_std", "inertia_min", "inertia_max", "silhouette_mean"]]
df_table(kt, widths=[2.4, 1.6, 2.5, 2.3, 2.3, 2.3, 2.6], fmt=4)
p("Each setting was run with 10 different random seeds at k = 3. With a single initialisation (n_init = 1) the inertia varied between 1277.93 and 1282.46 depending on the seed, i.e. some runs got stuck in a worse local optimum. "
  "With k-means++ and n_init = 20 (or random init with n_init >= 10) every seed reached the same best inertia of 1277.9285 (std 0.0000). Therefore n_init = 10 with k-means++ is adequate, and n_init = 20 removes seed dependence entirely. "
  "Reproducibility is secured by fixing random_state = 42.")

h1("16. Principal Component Analysis")
p("PCA rotates the data onto orthogonal axes (principal components) ordered by the variance they capture. The explained-variance ratio of a component is its eigenvalue divided by the sum of all eigenvalues; the cumulative ratio shows how much information a reduced representation keeps. "
  "Dimensionality reduction discards the remaining variance, so some information is always lost.")
pt = pd.read_csv(f"{RES}/pca_variance_table.csv")
df_table(pt.rename(columns={"explained_variance_ratio": "Explained var. ratio", "cumulative_variance": "Cumulative var."}), widths=[2.5, 3.5, 4.5, 4.5])
fig("11_pca_scree_cumulative.png", "Figure 11. Scree plot (left) and cumulative explained variance (right) with 80/90/95% thresholds.")
p(f"<b>Component selection.</b> Original features: 13. Components needed for 80% / 90% / 95% variance: {pc['n80']} / {pc['n90']} / {pc['n95']}. The Kaiser criterion (eigenvalue > 1) retains {pc['kaiser']}. "
  f"The first two components retain {pc['cum'][1]*100:.1f}% - sufficient for visualisation but not for faithful analysis. Retaining {pc['n80']} components reduces dimensionality by {(13-pc['n80'])/13*100:.1f}% (13 to {pc['n80']}) while keeping {pc['cum'][pc['n80']-1]*100:.1f}% of the variance. "
  f"PC1 is driven by {', '.join(list(pc['loadings_pc1'])[:3])} (a phenolic-content axis); PC2 by {', '.join(list(pc['loadings_pc2'])[:3])} (a colour/alcohol axis).")
h2("Clustering in PCA space vs the original scaled space")
pcc = pd.DataFrame(R["pca_clustering"])
df_table(pcc.rename(columns={"silhouette_in_own_space": "Silhouette (own space)", "davies_bouldin": "DB", "ARI_vs_original_kmeans": "ARI vs original K-Means", "ARI_vs_true_posthoc": "ARI vs true (post-hoc)"}),
         widths=[4.6, 1.2, 2.4, 1.6, 2.8, 2.8], fmt=4)
p("<b>Interpretation.</b> K-Means on 5 or 10 components produced exactly the same partition as on all 13 features (ARI = 1.0), so PCA gave a 61.5% smaller input with no change in the clustering. K-Means on 2 components produced a similar but not identical partition (ARI 0.9324 vs the original) "
  "and its post-hoc ARI (0.8951) is marginally lower than the original (0.8975). Its silhouette of 0.5611 is higher only because it is measured in a different, lower-dimensional space; silhouettes from different spaces are not comparable, "
  "so this must not be read as PCA improving clustering. The evidence supports PCA for compression and visualisation, not for better clusters.")
fig("12_pca_2d_clusters.png", "Figure 12. Clusters projected onto the first two principal components: K-Means (left), Ward (middle), true classes (right, reference only).")

# ============================ SUPERVISED ============================
h1("17. Cross-Validation")
p("Cross-validation estimates how well a model generalises by repeatedly training on part of the data and validating on the rest. In K-fold CV the data are split into K folds; each fold serves once as the validation set while the other K-1 folds train the model. "
  "Stratified K-fold additionally preserves the class proportions in every fold. <b>Note:</b> ordinary CV does not apply to clustering because there is no target to predict, so Section 11 used resampling stability instead. "
  "CV is demonstrated here on the Breast Cancer classification problem (positive class = malignant, 37.3% of samples).")
fb = pd.DataFrame(R["fold_balance"])
fbp = fb.pivot(index="fold", columns="splitter", values="malignant_%").reset_index()
df_table(fbp.rename(columns={"fold": "Fold", "KFold": "Malignant % in validation fold (KFold)", "StratifiedKFold": "Malignant % (StratifiedKFold)"}), widths=[2, 7, 7], fmt=2)
p("Plain KFold fold malignant rates range from 32.46% to 40.71% (spread 8.25 points); StratifiedKFold keeps them between 36.84% and 37.72% (spread 0.88 points).")
cvt = [["Fold", "Accuracy", "Precision", "Recall", "F1", "ROC-AUC"]]
for i in range(5):
    cvt.append([f"Fold {i+1}"] + [f4(cv["folds"][m][i]) for m in ["accuracy", "precision", "recall", "f1", "roc_auc"]])
cvt.append(["<b>Mean</b>"] + [f4(cv["mean"][m]) for m in ["accuracy", "precision", "recall", "f1", "roc_auc"]])
cvt.append(["<b>Std</b>"] + [f4(cv["std"][m]) for m in ["accuracy", "precision", "recall", "f1", "roc_auc"]])
table(cvt, widths=[2.2, 2.6, 2.6, 2.6, 2.6, 2.6])
fig("15_cv_fold_scores.png", "Figure 13. Per-fold scores of the Logistic Regression pipeline under stratified 5-fold CV.", w=12.5)
p(f"<b>Interpretation.</b> Mean accuracy is {cv['mean']['accuracy']:.4f} +/- {cv['std']['accuracy']:.4f} and mean ROC-AUC {cv['mean']['roc_auc']:.4f} +/- {cv['std']['roc_auc']:.4f}. Recall varies most between folds (0.8605 to 1.0000, std {cv['std']['recall']:.4f}), "
  f"so a single train/test split could easily have under- or over-stated the model's ability to detect malignant cases. Non-stratified KFold gave ROC-AUC {cv['kfold_auc_mean']:.4f} +/- {cv['kfold_auc_std']:.4f}, practically identical here because the classes are only mildly imbalanced.")

h1("18. Confusion Matrix")
p("A confusion matrix counts predictions against the truth. With malignant as the positive class: True Positive (TP) = malignant correctly flagged; True Negative (TN) = benign correctly cleared; False Positive (FP) = benign wrongly flagged; "
  "False Negative (FN) = malignant missed - the most dangerous error in screening. A confusion matrix needs genuine class labels, so it is used only for the supervised experiment and never for the unlabelled clustering. "
  f"The data were split stratified 80/20 (train {R['split']['train']}, test {R['split']['test']} with {R['split']['test_malignant']} malignant cases).")
fig("13_confusion_matrices.png", "Figure 14. Confusion matrices on the hold-out test set for default and tuned models.", w=11)
h1("19. Precision, Recall and F1-score")
p(f"<b>Worked example - {wk['model']}.</b> INPUT: TP = {wk['TP']}, FP = {wk['FP']}, FN = {wk['FN']}, TN = {wk['TN']}. FORMULAS and CALCULATION: "
  f"Precision = TP/(TP+FP) = {wk['TP']}/{wk['TP']+wk['FP']} = {wk['precision']:.4f}; Recall = TP/(TP+FN) = {wk['TP']}/{wk['TP']+wk['FN']} = {wk['recall']:.4f}; "
  f"F1 = 2PR/(P+R) = {wk['f1']:.4f}; Accuracy = (TP+TN)/N = {wk['accuracy']:.4f}. INTERPRETATION: when the model says 'malignant' it is right 97.5% of the time, but it finds only 92.86% of true malignant cases (3 missed). "
  "F1 is the harmonic mean, which is pulled toward the lower of precision and recall, so it penalises imbalance between the two.")
h1("20. ROC-AUC Analysis")
fig("14_roc_curves.png", "Figure 15. ROC curves of the four models on the test set.", w=10.5)
th = pd.DataFrame(R["threshold"])
p("The ROC curve plots True Positive Rate (= recall) against False Positive Rate (FP/(FP+TN)) as the decision threshold sweeps from 1 to 0; AUC is the probability that a randomly chosen malignant case receives a higher score than a randomly chosen benign one (0.5 = chance, 1.0 = perfect). "
  "Clustering algorithms output no class probabilities, which is why ROC-AUC is demonstrated only for supervised models.")
df_table(th.rename(columns={"threshold": "Threshold"}), widths=[2.2, 1.6, 1.6, 1.6, 1.6, 3, 3], fmt=4)
p("<b>Threshold effect (tuned Logistic Regression).</b> Lowering the threshold from 0.5 to 0.3 raised recall from 0.9286 to 0.9762 (FN 3 to 1) with precision essentially unchanged (0.9762 vs 0.9750) - a better operating point for screening. "
  "Raising it to 0.9 gave perfect precision but missed 9 of 42 malignant cases (recall 0.7857). AUC summarises all thresholds, whereas precision and recall describe one.")

h1("21. Hyperparameter Tuning")
p("Hyperparameters are settings chosen before training (e.g. regularisation strength C, tree depth). GridSearchCV tries every combination in a grid; RandomizedSearchCV samples a fixed number of combinations. Both were scored by 5-fold stratified CV ROC-AUC on the training set only; the test set was used once, afterwards.")
table([["Model", "Search", "Space tested", "Best configuration"],
       ["Logistic Regression", "GridSearchCV (12 configs, 60 fits)", "C in {0.001, 0.01, 0.1, 1, 10, 100}; class_weight in {None, balanced}", str(R["classification"]["grid_best"])],
       ["Random Forest", "RandomizedSearchCV (25 configs, 125 fits)", "n_estimators, max_depth, min_samples_split, min_samples_leaf, max_features", str(R["classification"]["rnd_best"])],
       ["Decision Tree", "GridSearchCV (56 configs, 280 fits)", "max_depth in {2,3,4,5,6,8,None}; min_samples_leaf in {1,2,5,10}; criterion in {gini, entropy}", str(R["dtree_tuning"]["best_params"])]],
      widths=[2.6, 3.6, 5.6, 4.4])
allm = pd.concat([cls, dt], ignore_index=True)[["model", "CV_ROC_AUC(train)", "TN", "FP", "FN", "TP", "accuracy", "precision", "recall", "f1", "roc_auc"]]
df_table(allm.rename(columns={"CV_ROC_AUC(train)": "CV AUC", "roc_auc": "Test AUC", "accuracy": "Acc", "precision": "Prec", "recall": "Rec"}), widths=[3.6, 1.5, 0.9, 0.9, 0.9, 0.9, 1.5, 1.5, 1.3, 1.3, 1.5], fmt=4)
p("<b>Before vs after.</b> Logistic Regression: CV AUC 0.9958 to 0.9958, test AUC 0.9960 to 0.9960 - no change, because the default C = 1 was already the best value in the grid. Random Forest: CV AUC 0.9889 to 0.9889, test AUC 0.9929 to 0.9929 - no change. "
  f"I report this honestly: tuning is not guaranteed to help when defaults are already near-optimal. "
  f"Decision Tree (defaults overfit: training accuracy 1.0000, depth {R['dtree_tuning']['depth_default']}): tuning lowered depth to {R['dtree_tuning']['depth_tuned']}, raised CV AUC from {dt.loc[0,'CV_ROC_AUC(train)']:.4f} to {dt.loc[1,'CV_ROC_AUC(train)']:.4f} and test AUC from {dt.loc[0,'roc_auc']:.4f} to {dt.loc[1,'roc_auc']:.4f}. "
  f"However, at the fixed 0.5 threshold, test recall fell from {dt.loc[0,'recall']:.4f} to {dt.loc[1,'recall']:.4f} and F1 from {dt.loc[0,'f1']:.4f} to {dt.loc[1,'f1']:.4f} (FN 4 to 9) while precision rose from {dt.loc[0,'precision']:.4f} to {dt.loc[1,'precision']:.4f}. "
  "Tuning therefore improved the ranking quality (AUC) but not the thresholded detection of malignant cases; with only 42 positive test cases a few errors also move these percentages substantially.")

h1("22. Experimental Results")
h2("A. Clustering results (Wine, internal metrics)")
table([["Method", "k", "Silhouette", "Davies-Bouldin", "Calinski-Harabasz", "Sizes"],
       ["K-Means (k-means++, n_init=10)", K, f4(km['metrics']['silhouette']), f4(km['metrics']['davies_bouldin']), f"{km['metrics']['calinski_harabasz']:.2f}", str(km['sizes'])],
       ["Hierarchical Ward", K, f4(hc['metrics']['silhouette']), f4(hc['metrics']['davies_bouldin']), f"{hc['metrics']['calinski_harabasz']:.2f}", str(hc['sizes'])]],
      widths=[4.6, 0.9, 2.2, 2.6, 3, 2.7])
h2("B. Classification results (Breast Cancer, test set - never mixed with clustering metrics)")
df_table(cls[["model", "accuracy", "precision", "recall", "f1", "roc_auc"]].rename(columns={"roc_auc": "ROC-AUC"}), widths=[5, 2.2, 2.2, 2.2, 2.2, 2.2])

h1("23. Technical Findings")
bullets([f"Three clusters is the best supported structure in the Wine data: elbow, silhouette, Davies-Bouldin and the dendrogram gap (15.085) all agree, and the solution is stable (resampling ARI {st['mean']:.3f}).",
         "Silhouette 0.28 means moderate separation; internal metrics say the clusters overlap, yet the post-hoc ARI of 0.90 shows they correspond well to the true wine classes.",
         "Linkage choice mattered more than distance metric: Ward worked, average and single linkage collapsed to one giant cluster plus outliers.",
         "PCA compresses 13 features to 5 with no change in K-Means assignments, but did not improve them.",
         "Cross-validation exposed fold-to-fold recall variation (0.86 to 1.00) that a single split would hide.",
         "Thresholding is a business decision: a 0.3 threshold gave 1 missed malignant case instead of 3 at no precision cost.",
         "Hyperparameter tuning helped only the overfitting model and only on AUC."])
h1("24. Challenges and Solutions")
table([["Challenge", "Solution"],
       ["Features on different scales dominated distances (magnesium 74.6% of a sample distance)", "Standardised all features before clustering"],
       ["Average and single linkage produced clusters of sizes [174, 3, 1] with deceptively low Davies-Bouldin", "Compared several metrics (silhouette, CH, cophenetic) and sizes before judging; kept Ward"],
       ["Silhouette in 2-D PCA (0.5611) looks better but is not comparable", "Compared assignments with ARI instead and stated that PCA does not improve clustering"],
       ["Confusion matrix/ROC cannot be applied to unlabelled clustering", "Used internal metrics and stability for clustering; used a separate supervised dataset for classification metrics"],
       ["Tuning gave no improvement for two models", "Reported it honestly and added an overfitting Decision Tree where tuning is informative"],
       ["Shell brace expansion failed when creating folders, so output directories were missing and the first EDA run crashed", "Created directories explicitly and re-ran; final results come from a clean full run"]], widths=[8.5, 7.5])
h1("25. Limitations")
bullets(["Wine has only 178 samples; silhouette differences of 0.007 between K-Means and Ward are small and should not be over-interpreted.",
         "The scaler for clustering was fitted on all data (acceptable without a test set).",
         "Test sets are small (114 samples, 42 malignant); one extra error changes recall by about 2.4 percentage points.",
         "Single random_state and one train/test split were used for tuning comparison; repeated CV would give tighter estimates.",
         "Only Euclidean-family distances and three linkage strategies were examined; no density-based clustering (DBSCAN) or Gaussian mixtures."])
h1("26. Conclusion")
p(f"Executed experiments show that the Wine data contain three stable, moderately separated groups (K-Means silhouette {f4(km['metrics']['silhouette'])}, stability ARI {st['mean']:.3f}) that match the true cultivars with ARI {f4(km['external_posthoc']['ARI'])}. "
  "K-Means slightly outperformed Ward hierarchical clustering here, PCA allowed a 61.5% reduction in dimensionality without altering the clusters, and the evaluation experiments demonstrated why metric choice (precision vs recall vs AUC), "
  "stratified cross-validation and decision threshold matter. Every figure in this report was generated by the accompanying code.")
h1("27. Future Enhancements")
bullets(["Add DBSCAN and Gaussian Mixture Models and compare with K-Means on non-spherical data.", "Apply the pipeline to the Mall Customers dataset to produce business-oriented customer segments.",
         "Use repeated stratified CV and nested CV for unbiased tuned-model estimates.", "Add calibration curves and precision-recall curves for imbalanced problems."])
h1("28. References")
bullets(["Pedregosa et al., Scikit-learn: Machine Learning in Python, JMLR 12, 2011.", "Rousseeuw, P. J., Silhouettes: a graphical aid to the interpretation and validation of cluster analysis, 1987.",
         "Jolliffe, I. T., Principal Component Analysis, Springer, 2002.", "Ward, J. H., Hierarchical grouping to optimize an objective function, JASA, 1963.",
         "Fawcett, T., An introduction to ROC analysis, Pattern Recognition Letters, 2006.", "Scikit-learn datasets: load_wine and load_breast_cancer (UCI Machine Learning Repository)."])
h1("29. GitHub Repository Link")
p("Repository: <i>add your GitHub URL here after pushing this folder</i> (for example https://github.com/&lt;username&gt;/&lt;repo&gt;).")


def footer(c, d):
    c.saveState(); c.setFont("Helvetica", 8); c.setFillColor(colors.grey)
    c.drawString(2 * cm, 1.1 * cm, "Week 3 Internship Report: Unsupervised Learning and Model Evaluation")
    c.drawRightString(A4[0] - 2 * cm, 1.1 * cm, f"Page {d.page}"); c.restoreState()

doc = SimpleDocTemplate("reports/week3_internship_report.pdf", pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                        title="Week 3 Internship Report: Unsupervised Learning and Model Evaluation", author="Pranav Y")
doc.build(S, onFirstPage=lambda c, d: None, onLaterPages=footer)
print("Report written: reports/week3_internship_report.pdf")
