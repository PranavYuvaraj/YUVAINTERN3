# Week 3: Unsupervised Learning and Model Evaluation

AI/ML internship, Week 3. Practical clustering (K-Means, Hierarchical), dimensionality reduction (PCA) and model evaluation
(cross-validation, confusion matrix, precision/recall/F1, ROC-AUC, hyperparameter tuning), with a full PDF report.

Two experiments are kept strictly separate:

| Part | Dataset | Techniques | Evaluated with |
|---|---|---|---|
| A. Unsupervised | Wine (178 samples, 13 features) | EDA, scaling, K-Means, Ward/Complete/Average/Single hierarchical, PCA | Inertia, silhouette, Davies-Bouldin, Calinski-Harabasz, resampling stability (ARI) |
| B. Supervised | Breast Cancer (569 samples, 30 features; malignant = positive) | Logistic Regression, Random Forest, Decision Tree | Stratified 5-fold CV, confusion matrix, precision, recall, F1, ROC-AUC, GridSearchCV / RandomizedSearchCV |

Wine class labels are **never** used to train clustering; they are used only afterwards as an external sanity check.

## Installation

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## How to run (in this order)

```bash
python step1_3_eda_preprocessing.py   # Steps 1-3: data understanding, EDA, scaling  (5 charts + EDA CSVs)
python run_all.py                     # Steps 4-9: clustering, PCA, CV, evaluation, tuning (10 charts, CSVs, results.json)
python build_report.py                # builds reports/week3_internship_report.pdf from results.json
```

Or open `notebooks/week3_analysis.ipynb` and run all cells. Everything uses `random_state = 42`, so results are reproducible.
Datasets are built into Scikit-learn, so no download is needed.

## Project structure

```
week3_unsupervised_learning/
├── README.md
├── requirements.txt
├── step1_3_eda_preprocessing.py      # EDA + preprocessing script
├── run_all.py                        # all experiments (K-Means, hierarchical, PCA, CV, tuning)
├── build_report.py                   # PDF report generator (reads results.json)
├── data/                             # saved Wine features (raw + scaled) and post-hoc labels
├── notebooks/week3_analysis.ipynb    # walk-through notebook
├── src/
│   ├── preprocessing.py              # loading, IQR outliers, standardisation
│   ├── clustering.py                 # K-Means sweep, linkage/metric comparison, stability
│   ├── dimensionality_reduction.py   # PCA helpers
│   └── evaluation.py                 # confusion-matrix based metrics
├── outputs/
│   ├── visualizations/               # 15 charts (01-15)
│   └── results/                      # 23 CSV tables, results.json, run_log.txt
└── reports/week3_internship_report.pdf
```

## Methodology

1. **Understand data:** shape, dtypes, missing values, duplicates.
2. **EDA:** summary statistics, skewness, IQR outliers, correlation, histograms, box plots, pair plot.
3. **Preprocess:** z-score standardisation (distance-based algorithms need equal feature scales).
4. **K-Means:** k = 2..10, elbow + silhouette + Davies-Bouldin to choose k; centroids; stability under 80% resampling; init / n_init tuning over 10 seeds.
5. **Hierarchical:** Ward dendrogram, k sweep, linkage comparison (Ward/complete/average/single), valid distance-metric combinations.
6. **Compare** K-Means vs Ward (internal metrics, agreement ARI, post-hoc ARI).
7. **PCA:** explained variance, scree, components for 80/90/95%, clustering in PCA space vs original space.
8. **Supervised evaluation:** stratified CV, confusion matrix, precision/recall/F1, ROC-AUC, threshold analysis.
9. **Tuning:** GridSearchCV (Logistic Regression, Decision Tree), RandomizedSearchCV (Random Forest), with before/after numbers.

## Key results (from the executed code)

**Clustering (Wine, k = 3, standardised features)**

| Metric | K-Means | Hierarchical (Ward) |
|---|---:|---:|
| Silhouette (higher better) | 0.2849 | 0.2774 |
| Davies-Bouldin (lower better) | 1.3892 | 1.4186 |
| Calinski-Harabasz (higher better) | 70.94 | 67.65 |
| Cluster sizes | 65 / 51 / 62 | 58 / 56 / 64 |
| ARI vs true classes (post-hoc only) | 0.8975 | 0.7899 |

- k = 3 was chosen because the elbow (inertia drop 22.96% from k=2 to 3, then at most 8.02%), the silhouette peak and the Davies-Bouldin minimum all agree.
- Agreement between the two methods: ARI = 0.8530. K-Means stability over 50 resamples: mean ARI 0.9785.
- Average and single linkage collapsed into sizes [174, 3, 1]; Ward was clearly best.
- PCA: 5 of 13 components keep 80.2% of the variance (first two keep 55.4%); K-Means on 5 components gives exactly the same clusters (ARI 1.0). PCA compresses, it did not improve clustering.

**Classification (Breast Cancer test set, positive = malignant)**

| Model | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---:|---:|---:|---:|---:|
| Logistic Regression (default) | 0.9649 | 0.9750 | 0.9286 | 0.9512 | 0.9960 |
| Logistic Regression (GridSearch) | 0.9649 | 0.9750 | 0.9286 | 0.9512 | 0.9960 |
| Random Forest (default) | 0.9737 | 1.0000 | 0.9286 | 0.9630 | 0.9929 |
| Random Forest (RandomizedSearch) | 0.9737 | 1.0000 | 0.9286 | 0.9630 | 0.9929 |

- Stratified 5-fold CV (Logistic Regression): accuracy 0.9737 +/- 0.0186, ROC-AUC 0.9953 +/- 0.0060; recall ranged 0.8605 to 1.0000 across folds.
- Tuning did **not** improve Logistic Regression or Random Forest (defaults were already optimal in the searched space).
- Tuning improved the overfitting Decision Tree's AUC (CV 0.9172 to 0.9559; test 0.9246 to 0.9688) but lowered its recall at the 0.5 threshold (0.9048 to 0.7857).
- Lowering the Logistic Regression threshold from 0.5 to 0.3 cut missed malignant cases from 3 to 1 with unchanged precision.

## Limitations

Small datasets (178 and 569 rows), one train/test split, no density-based clustering. See Section 25 of the report.

## Author

Pranav Y, B.E. Computer Science and Engineering, Erode Sengunthar Engineering College.
