"""Clustering helpers: K-Means sweep, hierarchical comparison, stability."""

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, AgglomerativeClustering
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score, adjusted_rand_score
from scipy.cluster.hierarchy import linkage, cophenet
from scipy.spatial.distance import pdist

RS = 42


def internal_metrics(X, labels):
    """Silhouette (higher better), Davies-Bouldin (lower better), Calinski-Harabasz (higher better)."""
    return {
        "silhouette": float(silhouette_score(X, labels)),
        "davies_bouldin": float(davies_bouldin_score(X, labels)),
        "calinski_harabasz": float(calinski_harabasz_score(X, labels)),
    }


def kmeans_sweep(X, k_range=range(2, 11), init="k-means++", n_init=10, random_state=RS):
    rows = []
    for k in k_range:
        km = KMeans(n_clusters=k, init=init, n_init=n_init, random_state=random_state).fit(X)
        m = internal_metrics(X, km.labels_)
        rows.append({"k": k, "inertia": float(km.inertia_), **m})
    return pd.DataFrame(rows)


def cluster_sizes(labels):
    s = pd.Series(labels).value_counts().sort_index()
    return pd.DataFrame({"size": s, "percent": (s / s.sum() * 100).round(2)})


def hierarchical_fit(X, k, linkage_name="ward", metric="euclidean"):
    kw = dict(n_clusters=k, linkage=linkage_name)
    kw["metric"] = metric
    return AgglomerativeClustering(**kw).fit(X)


def linkage_comparison(X, k=3):
    """Compare linkage strategies (euclidean) incl. cophenetic correlation."""
    d = pdist(X)
    rows = []
    for name in ["ward", "complete", "average", "single"]:
        Z = linkage(X, method=name)
        coph, _ = cophenet(Z, d)
        lab = hierarchical_fit(X, k, name).labels_
        rows.append({"linkage": name, "cophenetic_corr": float(coph),
                     **internal_metrics(X, lab),
                     "sizes": sorted(pd.Series(lab).value_counts().tolist(), reverse=True)})
    return pd.DataFrame(rows)


def metric_comparison(X, k=3):
    """Linkage x distance-metric combinations that are mathematically valid.
    Ward only supports euclidean."""
    rows = []
    for link in ["complete", "average"]:
        for met in ["euclidean", "manhattan", "cosine"]:
            lab = hierarchical_fit(X, k, link, met).labels_
            rows.append({"linkage": link, "metric": met, **internal_metrics(X, lab)})
    return pd.DataFrame(rows)


def kmeans_stability(X, k, n_boot=50, frac=0.8, seed=RS):
    """Resampling stability: fit on 80% subsamples, predict all points, compare with the full-data labels (ARI)."""
    rng = np.random.RandomState(seed)
    base = KMeans(n_clusters=k, n_init=10, random_state=RS).fit(X).labels_
    aris = []
    for _ in range(n_boot):
        idx = rng.choice(len(X), int(frac * len(X)), replace=False)
        km = KMeans(n_clusters=k, n_init=10, random_state=int(rng.randint(10_000))).fit(X.iloc[idx])
        aris.append(adjusted_rand_score(base, km.predict(X)))
    return np.array(aris)
