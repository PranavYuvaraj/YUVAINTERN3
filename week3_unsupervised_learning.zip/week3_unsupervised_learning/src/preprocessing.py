"""Reusable data loading and preprocessing helpers for Week 3."""

import pandas as pd
from sklearn.datasets import load_wine
from sklearn.preprocessing import StandardScaler


def load_wine_data():
    """Return (features DataFrame, labels Series).

    Labels are returned separately and are NEVER used to train clustering.
    They are kept only for post-hoc interpretation.
    """
    data = load_wine(as_frame=True)
    X = data.data.copy()
    y = data.target.copy()
    y.name = "wine_class"
    return X, y


def iqr_outlier_counts(X: pd.DataFrame) -> pd.Series:
    """Count values outside [Q1 - 1.5*IQR, Q3 + 1.5*IQR] for each feature."""
    q1, q3 = X.quantile(0.25), X.quantile(0.75)
    iqr = q3 - q1
    low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    return ((X < low) | (X > high)).sum()


def standardize(X: pd.DataFrame):
    """Z-score standardization: z = (x - mean) / std. Returns (X_scaled, scaler)."""
    scaler = StandardScaler()
    X_scaled = pd.DataFrame(scaler.fit_transform(X), columns=X.columns, index=X.index)
    return X_scaled, scaler
