"""PCA helpers."""

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA


def fit_pca(X):
    pca = PCA(random_state=42).fit(X)
    evr = pca.explained_variance_ratio_
    table = pd.DataFrame({
        "component": [f"PC{i+1}" for i in range(len(evr))],
        "eigenvalue": pca.explained_variance_,
        "explained_variance_ratio": evr,
        "cumulative_variance": np.cumsum(evr),
    })
    return pca, table


def n_components_for(cum, threshold):
    return int(np.argmax(cum >= threshold) + 1)


def top_loadings(pca, columns, pc=0, n=4):
    s = pd.Series(pca.components_[pc], index=columns)
    return s.reindex(s.abs().sort_values(ascending=False).index).head(n)
