"""
Week 3: Unsupervised Learning & Model Evaluation  -  full experiment pipeline.

PART A (unsupervised)  : Wine dataset  -> K-Means, Hierarchical, PCA
PART B (supervised)    : Breast Cancer -> CV, confusion matrix, P/R/F1, ROC-AUC, tuning

Run:  python run_all.py
Everything printed here is real output; results are saved to outputs/results/results.json
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

warnings.filterwarnings("ignore")
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)
sys.path.insert(0, os.path.join(HERE, "src"))

from sklearn.cluster import KMeans
from sklearn.metrics import (adjusted_rand_score, normalized_mutual_info_score, homogeneity_score,
                             silhouette_samples, confusion_matrix, roc_curve, ConfusionMatrixDisplay)
from sklearn.model_selection import (train_test_split, StratifiedKFold, KFold, cross_validate,
                                     cross_val_score, GridSearchCV, RandomizedSearchCV)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import load_breast_cancer
from scipy.cluster.hierarchy import linkage, dendrogram

from preprocessing import load_wine_data, standardize
from clustering import (kmeans_sweep, cluster_sizes, hierarchical_fit, linkage_comparison,
                        metric_comparison, kmeans_stability, internal_metrics)
from dimensionality_reduction import fit_pca, n_components_for, top_loadings
from evaluation import classification_report_dict, manual_metrics

VIS, RES = "outputs/visualizations", "outputs/results"
os.makedirs(VIS, exist_ok=True); os.makedirs(RES, exist_ok=True)
sns.set_theme(style="whitegrid")
pd.set_option("display.width", 170); pd.set_option("display.max_columns", 30)
RS = 42
R = {}


def hdr(t):
    print("\n" + "=" * 78 + f"\n{t}\n" + "=" * 78)


def save(fig, name):
    fig.tight_layout(); fig.savefig(f"{VIS}/{name}", dpi=110); plt.close(fig)


# =====================================================================
# PART A - UNSUPERVISED LEARNING (Wine)
# =====================================================================
X, y = load_wine_data()
Xs, scaler = standardize(X)
R["data"] = {"n_samples": int(X.shape[0]), "n_features": int(X.shape[1])}

# ---------------- K-MEANS ----------------
hdr("STEP 4: K-MEANS - elbow / silhouette sweep (k = 2..10, n_init=10, random_state=42)")
sweep = kmeans_sweep(Xs)
sweep["inertia_drop_%"] = (-sweep["inertia"].pct_change() * 100).round(2)
print(sweep.round(4).to_string(index=False))
sweep.round(4).to_csv(f"{RES}/kmeans_k_sweep.csv", index=False)

k_sil = int(sweep.loc[sweep["silhouette"].idxmax(), "k"])
k_db = int(sweep.loc[sweep["davies_bouldin"].idxmin(), "k"])
# elbow = k with largest second difference of inertia (sharpest bend)
inert = sweep["inertia"].values
second_diff = inert[:-2] - 2 * inert[1:-1] + inert[2:]
k_elbow = int(sweep["k"].values[1:-1][np.argmax(second_diff)])
K = k_sil
print(f"\nBest k by silhouette = {k_sil} | by Davies-Bouldin = {k_db} | elbow (max 2nd difference) = {k_elbow}")
print(f"=> selected K = {K}")
R["kmeans_sweep"] = {"k_silhouette": k_sil, "k_davies_bouldin": k_db, "k_elbow": k_elbow, "K": K,
                     "table": sweep.round(4).to_dict(orient="records")}

fig, ax = plt.subplots(1, 3, figsize=(17, 4.6))
ax[0].plot(sweep.k, sweep.inertia, "o-", color="navy"); ax[0].axvline(K, ls="--", c="red")
ax[0].set(title="Elbow Method: Inertia vs k", xlabel="k (clusters)", ylabel="Inertia (WCSS)")
ax[1].plot(sweep.k, sweep.silhouette, "s-", color="darkgreen"); ax[1].axvline(K, ls="--", c="red")
ax[1].set(title="Silhouette Score vs k (higher = better)", xlabel="k", ylabel="Silhouette")
ax[2].plot(sweep.k, sweep.davies_bouldin, "^-", color="purple"); ax[2].axvline(K, ls="--", c="red")
ax[2].set(title="Davies-Bouldin Index vs k (lower = better)", xlabel="k", ylabel="DB index")
save(fig, "06_elbow_silhouette_db.png")

km = KMeans(n_clusters=K, init="k-means++", n_init=10, random_state=RS).fit(Xs)
km_labels = km.labels_
km_m = internal_metrics(Xs, km_labels)
km_sizes = cluster_sizes(km_labels)
print(f"\nFinal K-Means (k={K}): inertia={km.inertia_:.3f}, iterations={km.n_iter_}")
print("Internal metrics:", {k: round(v, 4) for k, v in km_m.items()})
print("Cluster sizes:\n", km_sizes.to_string())

centroids_orig = pd.DataFrame(scaler.inverse_transform(km.cluster_centers_), columns=X.columns).round(3)
centroids_orig.index.name = "cluster"
centroids_z = pd.DataFrame(km.cluster_centers_, columns=X.columns).round(3)
print("\nCentroids (original units):\n", centroids_orig.T.to_string())
centroids_orig.to_csv(f"{RES}/kmeans_centroids_original_units.csv")
centroids_z.to_csv(f"{RES}/kmeans_centroids_standardized.csv")

# post-hoc external check (labels were NOT used for training)
ct_km = pd.crosstab(pd.Series(y.values, name="true_class"), pd.Series(km_labels, name="kmeans_cluster"))
km_ext = {"ARI": float(adjusted_rand_score(y, km_labels)),
          "NMI": float(normalized_mutual_info_score(y, km_labels)),
          "homogeneity": float(homogeneity_score(y, km_labels))}
print("\nPOST-HOC external check vs true wine class:", {k: round(v, 4) for k, v in km_ext.items()})
print(ct_km.to_string())
ct_km.to_csv(f"{RES}/kmeans_vs_true_class_crosstab.csv")

# silhouette plot
sil_s = silhouette_samples(Xs, km_labels)
fig, ax = plt.subplots(figsize=(8, 5.5)); ylo = 10
for c in range(K):
    v = np.sort(sil_s[km_labels == c]); yh = ylo + len(v)
    ax.fill_betweenx(np.arange(ylo, yh), 0, v, alpha=0.75, label=f"cluster {c} (n={len(v)}, mean={v.mean():.3f})")
    ylo = yh + 10
ax.axvline(km_m["silhouette"], color="red", ls="--", label=f"overall = {km_m['silhouette']:.3f}")
ax.set(title=f"Silhouette Plot - K-Means (k={K})", xlabel="Silhouette coefficient", ylabel="Samples (sorted per cluster)")
ax.legend(fontsize=8); save(fig, "07_kmeans_silhouette_plot.png")

fig, ax = plt.subplots(figsize=(12, 3.2 + K * 0.5))
sns.heatmap(centroids_z, cmap="coolwarm", center=0, annot=True, fmt=".2f", annot_kws={"size": 8}, ax=ax)
ax.set(title="K-Means Cluster Profiles (centroids in standardized units)", ylabel="cluster")
plt.setp(ax.get_xticklabels(), rotation=40, ha="right"); save(fig, "08_kmeans_centroid_heatmap.png")

R["kmeans_final"] = {"K": K, "inertia": float(km.inertia_), "n_iter": int(km.n_iter_), "metrics": km_m,
                     "sizes": km_sizes["size"].tolist(), "percents": km_sizes["percent"].tolist(),
                     "external_posthoc": km_ext, "crosstab": ct_km.values.tolist()}

# worked example: assign one point to nearest centroid
i0 = 0
d = np.linalg.norm(km.cluster_centers_ - Xs.iloc[i0].values, axis=1)
print(f"\nWORKED EXAMPLE (assignment): sample {i0} distances to centroids = {np.round(d, 3).tolist()} -> cluster {int(d.argmin())}")
R["kmeans_worked_example"] = {"sample": i0, "distances": np.round(d, 4).tolist(), "assigned": int(d.argmin())}

# ---------------- K-MEANS TUNING ----------------
hdr("STEP 9a: K-MEANS HYPERPARAMETER TUNING (init x n_init, 10 random seeds each, k fixed)")
rows = []
for init in ["k-means++", "random"]:
    for n_init in [1, 5, 10, 20]:
        inr, sil = [], []
        for seed in range(10):
            m = KMeans(n_clusters=K, init=init, n_init=n_init, random_state=seed).fit(Xs)
            inr.append(m.inertia_); sil.append(internal_metrics(Xs, m.labels_)["silhouette"])
        rows.append({"init": init, "n_init": n_init, "inertia_mean": np.mean(inr), "inertia_std": np.std(inr),
                     "inertia_min": np.min(inr), "inertia_max": np.max(inr),
                     "silhouette_mean": np.mean(sil), "silhouette_std": np.std(sil)})
kt = pd.DataFrame(rows).round(4)
print(kt.to_string(index=False)); kt.to_csv(f"{RES}/kmeans_init_tuning.csv", index=False)
R["kmeans_tuning"] = kt.to_dict(orient="records")

hdr("K-MEANS STABILITY (50 bootstrap-style 80% resamples, ARI vs full-data clustering)")
aris = kmeans_stability(Xs, K)
print(f"ARI mean={aris.mean():.4f} std={aris.std():.4f} min={aris.min():.4f} max={aris.max():.4f}")
R["kmeans_stability"] = {"mean": float(aris.mean()), "std": float(aris.std()), "min": float(aris.min()), "max": float(aris.max())}
fig, ax = plt.subplots(figsize=(6.5, 4)); sns.histplot(aris, bins=15, ax=ax, color="teal")
ax.set(title="K-Means Stability: ARI over 50 resamples", xlabel="Adjusted Rand Index vs full-data clustering")
save(fig, "09_kmeans_stability.png")

# ---------------- HIERARCHICAL ----------------
hdr("STEP 5: HIERARCHICAL (AGGLOMERATIVE) CLUSTERING")
Z = linkage(Xs, method="ward")
last = Z[-8:, 2]
print("Last 8 Ward merge heights:", np.round(last, 3).tolist())
gaps = np.diff(Z[-8:, 2])
print("Gaps between consecutive last merges:", np.round(gaps, 3).tolist())
cut_k3 = (Z[-3, 2] + Z[-2, 2]) / 2
fig, ax = plt.subplots(figsize=(13, 5.5))
dendrogram(Z, truncate_mode="lastp", p=30, color_threshold=cut_k3, leaf_rotation=90, leaf_font_size=8,
           show_contracted=True, ax=ax)
ax.axhline(cut_k3, ls="--", c="black", label=f"cut at height {cut_k3:.2f} (k=3)")
ax.set(title="Ward Dendrogram (last 30 merged clusters shown)", xlabel="Cluster (number of samples)", ylabel="Ward merge distance")
ax.legend(); save(fig, "10_dendrogram_ward.png")
R["dendrogram"] = {"last_heights": np.round(last, 3).tolist(), "cut_k3": float(cut_k3)}

hs = []
for k in range(2, 9):
    lab = hierarchical_fit(Xs, k, "ward").labels_
    hs.append({"k": k, **internal_metrics(Xs, lab)})
hs = pd.DataFrame(hs).round(4)
print("\nWard sweep:\n", hs.to_string(index=False)); hs.to_csv(f"{RES}/ward_k_sweep.csv", index=False)
R["ward_sweep"] = hs.to_dict(orient="records")
k_ward_best = int(hs.loc[hs["silhouette"].idxmax(), "k"])

lc = linkage_comparison(Xs, k=K)
lc["ARI_vs_true_posthoc"] = [adjusted_rand_score(y, hierarchical_fit(Xs, K, l).labels_) for l in lc["linkage"]]
lc_show = lc.copy(); lc_show[["cophenetic_corr", "silhouette", "davies_bouldin", "calinski_harabasz", "ARI_vs_true_posthoc"]] = \
    lc_show[["cophenetic_corr", "silhouette", "davies_bouldin", "calinski_harabasz", "ARI_vs_true_posthoc"]].round(4)
print(f"\nLinkage comparison (euclidean, k={K}):\n", lc_show.to_string(index=False))
lc_show.to_csv(f"{RES}/linkage_comparison.csv", index=False)
R["linkage_comparison"] = lc_show.to_dict(orient="records")

mc = metric_comparison(Xs, k=K).round(4)
print(f"\nDistance-metric comparison (k={K}; Ward supports euclidean only):\n", mc.to_string(index=False))
mc.to_csv(f"{RES}/hier_metric_comparison.csv", index=False)
R["metric_comparison"] = mc.to_dict(orient="records")

hc = hierarchical_fit(Xs, K, "ward"); hc_labels = hc.labels_
hc_m = internal_metrics(Xs, hc_labels); hc_sizes = cluster_sizes(hc_labels)
hc_ext = {"ARI": float(adjusted_rand_score(y, hc_labels)), "NMI": float(normalized_mutual_info_score(y, hc_labels)),
          "homogeneity": float(homogeneity_score(y, hc_labels))}
ct_hc = pd.crosstab(pd.Series(y.values, name="true_class"), pd.Series(hc_labels, name="ward_cluster"))
print(f"\nFinal Hierarchical (Ward, k={K}): metrics={ {k: round(v, 4) for k, v in hc_m.items()} }")
print(hc_sizes.to_string()); print("POST-HOC vs true class:", {k: round(v, 4) for k, v in hc_ext.items()}); print(ct_hc.to_string())
R["hier_final"] = {"K": K, "metrics": hc_m, "sizes": hc_sizes["size"].tolist(), "percents": hc_sizes["percent"].tolist(),
                   "external_posthoc": hc_ext, "crosstab": ct_hc.values.tolist(), "k_ward_best_silhouette": k_ward_best}

# ---------------- COMPARISON ----------------
hdr("STEP 6: K-MEANS vs HIERARCHICAL (clustering metrics only)")
agree = float(adjusted_rand_score(km_labels, hc_labels))
ct_cmp = pd.crosstab(pd.Series(km_labels, name="kmeans"), pd.Series(hc_labels, name="ward"))
cmp_tbl = pd.DataFrame({
    "Metric": ["Number of clusters", "Silhouette (higher better)", "Davies-Bouldin (lower better)",
               "Calinski-Harabasz (higher better)", "Cluster sizes", "ARI vs true class (post-hoc)"],
    "K-Means": [K, round(km_m["silhouette"], 4), round(km_m["davies_bouldin"], 4), round(km_m["calinski_harabasz"], 2),
                str(km_sizes["size"].tolist()), round(km_ext["ARI"], 4)],
    "Hierarchical (Ward)": [K, round(hc_m["silhouette"], 4), round(hc_m["davies_bouldin"], 4), round(hc_m["calinski_harabasz"], 2),
                            str(hc_sizes["size"].tolist()), round(hc_ext["ARI"], 4)]})
print(cmp_tbl.to_string(index=False)); print(f"\nAgreement between the two methods (ARI) = {agree:.4f}"); print(ct_cmp.to_string())
cmp_tbl.to_csv(f"{RES}/clustering_comparison.csv", index=False); ct_cmp.to_csv(f"{RES}/kmeans_vs_ward_crosstab.csv")
R["comparison"] = {"agreement_ARI": agree, "crosstab": ct_cmp.values.tolist()}

# ---------------- PCA ----------------
hdr("STEP 7: PCA")
pca, pt = fit_pca(Xs)
print(pt.round(4).to_string(index=False)); pt.round(4).to_csv(f"{RES}/pca_variance_table.csv", index=False)
cum = pt["cumulative_variance"].values
n80, n90, n95 = (n_components_for(cum, t) for t in (0.80, 0.90, 0.95))
n_kaiser = int((pt["eigenvalue"] > 1).sum())
print(f"\nComponents for 80% / 90% / 95% variance: {n80} / {n90} / {n95} | Kaiser (eigenvalue>1): {n_kaiser}")
for pc in (0, 1):
    print(f"Top loadings PC{pc+1}:", top_loadings(pca, X.columns, pc).round(3).to_dict())
R["pca"] = {"n_features": int(X.shape[1]), "n80": n80, "n90": n90, "n95": n95, "kaiser": n_kaiser,
            "evr": pt["explained_variance_ratio"].round(4).tolist(), "cum": pt["cumulative_variance"].round(4).tolist(),
            "eigenvalues": pt["eigenvalue"].round(4).tolist(),
            "loadings_pc1": top_loadings(pca, X.columns, 0).round(3).to_dict(),
            "loadings_pc2": top_loadings(pca, X.columns, 1).round(3).to_dict()}

fig, ax = plt.subplots(1, 2, figsize=(13, 4.6))
ax[0].bar(range(1, 14), pt["explained_variance_ratio"], color="steelblue"); ax[0].plot(range(1, 14), pt["explained_variance_ratio"], "ro-")
ax[0].set(title="Scree Plot", xlabel="Principal component", ylabel="Explained variance ratio")
ax[1].plot(range(1, 14), cum, "o-", color="darkgreen")
for t, c in ((0.80, "orange"), (0.90, "red"), (0.95, "purple")):
    ax[1].axhline(t, ls="--", c=c, label=f"{int(t*100)}%")
ax[1].set(title="Cumulative Explained Variance", xlabel="Number of components", ylabel="Cumulative variance"); ax[1].legend()
save(fig, "11_pca_scree_cumulative.png")

# clustering on PCA space vs original scaled space
rows = [{"space": f"Original scaled ({X.shape[1]} features)", "n_dim": 13, "silhouette_in_own_space": km_m["silhouette"],
         "davies_bouldin": km_m["davies_bouldin"], "ARI_vs_original_kmeans": 1.0, "ARI_vs_true_posthoc": km_ext["ARI"]}]
for n in sorted({2, n80, n95}):
    Zp = pca.transform(Xs)[:, :n]
    lab = KMeans(n_clusters=K, n_init=10, random_state=RS).fit_predict(Zp)
    mm = internal_metrics(pd.DataFrame(Zp), lab)
    rows.append({"space": f"PCA ({n} components, {cum[n-1]*100:.1f}% var)", "n_dim": n,
                 "silhouette_in_own_space": mm["silhouette"], "davies_bouldin": mm["davies_bouldin"],
                 "ARI_vs_original_kmeans": adjusted_rand_score(km_labels, lab),
                 "ARI_vs_true_posthoc": adjusted_rand_score(y, lab)})
pc_tbl = pd.DataFrame(rows).round(4)
print("\nK-Means on PCA space vs original scaled space:\n", pc_tbl.to_string(index=False))
pc_tbl.to_csv(f"{RES}/kmeans_pca_vs_original.csv", index=False)
R["pca_clustering"] = pc_tbl.to_dict(orient="records")

P2 = pca.transform(Xs)[:, :2]
cent2 = pca.transform(km.cluster_centers_)[:, :2]
fig, ax = plt.subplots(1, 3, figsize=(18, 5.2))
for a, lab, ttl in zip(ax, (km_labels, hc_labels, y.values),
                       (f"K-Means (k={K})", f"Ward Hierarchical (k={K})", "True wine class (post-hoc, for reference)")):
    sc = a.scatter(P2[:, 0], P2[:, 1], c=lab, cmap="Set1", s=35, edgecolor="k", linewidth=0.3)
    a.set(title=ttl, xlabel=f"PC1 ({pt.explained_variance_ratio[0]*100:.1f}%)", ylabel=f"PC2 ({pt.explained_variance_ratio[1]*100:.1f}%)")
ax[0].scatter(cent2[:, 0], cent2[:, 1], marker="X", s=260, c="gold", edgecolor="k", label="centroids"); ax[0].legend()
save(fig, "12_pca_2d_clusters.png")

# =====================================================================
# PART B - SUPERVISED MODEL EVALUATION (Breast Cancer)
# =====================================================================
hdr("STEP 8: SUPERVISED EVALUATION DEMO (Breast Cancer) - positive class = MALIGNANT")
bc = load_breast_cancer(as_frame=True)
Xb = bc.data
yb = (bc.target == 0).astype(int)  # 1 = malignant (the class we must not miss)
print(f"Samples={Xb.shape[0]}, features={Xb.shape[1]}, malignant={int(yb.sum())} ({yb.mean()*100:.1f}%), benign={int((1-yb).sum())}")
R["bc_data"] = {"n": int(Xb.shape[0]), "features": int(Xb.shape[1]), "malignant": int(yb.sum()), "benign": int((1 - yb).sum())}

lr_pipe = lambda **kw: Pipeline([("scaler", StandardScaler()), ("clf", LogisticRegression(max_iter=5000, **kw))])
skf = StratifiedKFold(5, shuffle=True, random_state=RS)
kf = KFold(5, shuffle=True, random_state=RS)

# class balance per fold (worked example)
fold_rows = []
for name, splitter in (("KFold", kf), ("StratifiedKFold", skf)):
    for f, (_, va) in enumerate(splitter.split(Xb, yb), 1):
        fold_rows.append({"splitter": name, "fold": f, "val_size": len(va), "malignant_in_val": int(yb.iloc[va].sum()),
                          "malignant_%": round(yb.iloc[va].mean() * 100, 2)})
fold_df = pd.DataFrame(fold_rows); print(fold_df.to_string(index=False)); fold_df.to_csv(f"{RES}/cv_fold_class_balance.csv", index=False)
R["fold_balance"] = fold_rows

scoring = ["accuracy", "precision", "recall", "f1", "roc_auc"]
cv_res = cross_validate(lr_pipe(), Xb, yb, cv=skf, scoring=scoring)
cv_tbl = pd.DataFrame({s: cv_res[f"test_{s}"] for s in scoring}); cv_tbl.index = [f"Fold {i}" for i in range(1, 6)]
cv_sum = pd.DataFrame({"mean": cv_tbl.mean(), "std": cv_tbl.std()}).T
print("\n5-fold Stratified CV (Logistic Regression pipeline, full data):\n", pd.concat([cv_tbl, cv_sum]).round(4).to_string())
pd.concat([cv_tbl, cv_sum]).round(4).to_csv(f"{RES}/cv_scores_logreg.csv")
cv_kf = cross_val_score(lr_pipe(), Xb, yb, cv=kf, scoring="roc_auc")
cv_skf_auc = cv_tbl["roc_auc"].values
print(f"\nROC-AUC KFold mean={cv_kf.mean():.4f} std={cv_kf.std():.4f} | Stratified mean={cv_skf_auc.mean():.4f} std={cv_skf_auc.std():.4f}")
R["cv"] = {"folds": cv_tbl.round(4).to_dict(orient="list"), "mean": cv_tbl.mean().round(4).to_dict(), "std": cv_tbl.std().round(4).to_dict(),
           "kfold_auc_mean": float(cv_kf.mean()), "kfold_auc_std": float(cv_kf.std())}
fig, ax = plt.subplots(figsize=(9, 4.6)); cv_tbl.plot.bar(ax=ax, rot=0, width=0.8)
ax.set(title="5-Fold Stratified CV Scores per Fold (Logistic Regression)", ylabel="Score", ylim=(0.88, 1.01)); ax.legend(ncol=5, fontsize=8, loc="lower center")
save(fig, "15_cv_fold_scores.png")

# train/test split
Xtr, Xte, ytr, yte = train_test_split(Xb, yb, test_size=0.2, stratify=yb, random_state=RS)
print(f"\nTrain={len(Xtr)} (malignant {int(ytr.sum())}) | Test={len(Xte)} (malignant {int(yte.sum())})")
R["split"] = {"train": len(Xtr), "test": len(Xte), "test_malignant": int(yte.sum())}

# ---- tuning
hdr("STEP 9b: HYPERPARAMETER TUNING (GridSearchCV on Logistic Regression, RandomizedSearchCV on Random Forest)")
base_lr = lr_pipe().fit(Xtr, ytr)
base_lr_cv = cross_val_score(lr_pipe(), Xtr, ytr, cv=skf, scoring="roc_auc").mean()
grid = GridSearchCV(lr_pipe(), {"clf__C": [0.001, 0.01, 0.1, 1, 10, 100], "clf__class_weight": [None, "balanced"]},
                    cv=skf, scoring="roc_auc", n_jobs=-1).fit(Xtr, ytr)
pd.DataFrame(grid.cv_results_)[["param_clf__C", "param_clf__class_weight", "mean_test_score", "std_test_score", "rank_test_score"]]\
    .round(4).sort_values("rank_test_score").to_csv(f"{RES}/gridsearch_logreg_results.csv", index=False)
print(f"LogReg default: CV AUC={base_lr_cv:.4f} | GridSearch best {grid.best_params_}: CV AUC={grid.best_score_:.4f} (12 configs x 5 folds = 60 fits)")

base_rf = RandomForestClassifier(random_state=RS).fit(Xtr, ytr)
base_rf_cv = cross_val_score(RandomForestClassifier(random_state=RS), Xtr, ytr, cv=skf, scoring="roc_auc").mean()
rnd = RandomizedSearchCV(RandomForestClassifier(random_state=RS), {
    "n_estimators": [50, 100, 200, 300, 500], "max_depth": [None, 3, 5, 8, 12], "min_samples_split": [2, 5, 10],
    "min_samples_leaf": [1, 2, 4], "max_features": ["sqrt", "log2", 0.5]},
    n_iter=25, cv=skf, scoring="roc_auc", random_state=RS, n_jobs=-1).fit(Xtr, ytr)
pd.DataFrame(rnd.cv_results_)[["params", "mean_test_score", "std_test_score", "rank_test_score"]].round(4)\
    .sort_values("rank_test_score").to_csv(f"{RES}/randomsearch_rf_results.csv", index=False)
print(f"RandForest default: CV AUC={base_rf_cv:.4f} | RandomizedSearch best {rnd.best_params_}: CV AUC={rnd.best_score_:.4f} (25 configs x 5 folds = 125 fits)")

models = {"LogReg (default)": base_lr, "LogReg (GridSearch)": grid.best_estimator_,
          "RandForest (default)": base_rf, "RandForest (RandomSearch)": rnd.best_estimator_}
cv_scores = {"LogReg (default)": base_lr_cv, "LogReg (GridSearch)": grid.best_score_,
             "RandForest (default)": base_rf_cv, "RandForest (RandomSearch)": rnd.best_score_}
rows, fitted_scores = [], {}
for name, m in models.items():
    proba = m.predict_proba(Xte)[:, 1]; pred = (proba >= 0.5).astype(int)
    rep = classification_report_dict(yte, pred, proba); fitted_scores[name] = (proba, pred)
    rows.append({"model": name, "CV_ROC_AUC(train)": cv_scores[name], **rep})
ev = pd.DataFrame(rows).round(4)
print("\nHOLD-OUT TEST RESULTS (positive = malignant, threshold 0.5):\n", ev.to_string(index=False))
ev.to_csv(f"{RES}/classification_test_results.csv", index=False)
R["classification"] = {"table": ev.to_dict(orient="records"), "grid_best": {k: (None if v is None else v) for k, v in grid.best_params_.items()},
                       "rnd_best": {k: (None if v is None else v) for k, v in rnd.best_params_.items()}}

# confusion matrices
fig, ax = plt.subplots(2, 2, figsize=(9, 8))
for a, (name, (proba, pred)) in zip(ax.ravel(), fitted_scores.items()):
    ConfusionMatrixDisplay(confusion_matrix(yte, pred), display_labels=["Benign", "Malignant"]).plot(ax=a, cmap="Blues", colorbar=False)
    a.set_title(name, fontsize=10)
fig.suptitle("Confusion Matrices on the Hold-out Test Set (n=%d)" % len(yte)); save(fig, "13_confusion_matrices.png")

# ROC
fig, ax = plt.subplots(figsize=(7, 6))
for name, (proba, _) in fitted_scores.items():
    fpr, tpr, _ = roc_curve(yte, proba)
    from sklearn.metrics import roc_auc_score
    ax.plot(fpr, tpr, label=f"{name} (AUC={roc_auc_score(yte, proba):.4f})")
ax.plot([0, 1], [0, 1], "k--", label="Random guess (AUC=0.5)")
ax.set(title="ROC Curves on the Test Set", xlabel="False Positive Rate (FPR)", ylabel="True Positive Rate (TPR / Recall)"); ax.legend(loc="lower right", fontsize=8)
save(fig, "14_roc_curves.png")

# worked examples
best_name = "LogReg (GridSearch)"
r = ev[ev.model == best_name].iloc[0]
p_, rc_, f1_, ac_ = manual_metrics(r.TP, r.FP, r.FN, r.TN)
print(f"\nWORKED EXAMPLE ({best_name}): TP={int(r.TP)} FP={int(r.FP)} FN={int(r.FN)} TN={int(r.TN)}")
print(f"  Precision = TP/(TP+FP) = {int(r.TP)}/{int(r.TP+r.FP)} = {p_:.4f}\n  Recall = TP/(TP+FN) = {int(r.TP)}/{int(r.TP+r.FN)} = {rc_:.4f}")
print(f"  F1 = 2PR/(P+R) = {f1_:.4f}\n  Accuracy = (TP+TN)/N = {ac_:.4f}")
R["worked_metrics"] = {"model": best_name, "TP": int(r.TP), "FP": int(r.FP), "FN": int(r.FN), "TN": int(r.TN),
                       "precision": p_, "recall": rc_, "f1": f1_, "accuracy": ac_}

proba = fitted_scores[best_name][0]; th_rows = []
for th in (0.1, 0.3, 0.5, 0.7, 0.9):
    pr = (proba >= th).astype(int); tn, fp, fn, tp = confusion_matrix(yte, pr).ravel()
    th_rows.append({"threshold": th, "TP": int(tp), "FP": int(fp), "FN": int(fn), "TN": int(tn),
                    "precision": tp / (tp + fp) if tp + fp else float("nan"), "recall": tp / (tp + fn)})
th = pd.DataFrame(th_rows).round(4); print("\nThreshold effect (" + best_name + "):\n", th.to_string(index=False))
th.to_csv(f"{RES}/threshold_analysis.csv", index=False); R["threshold"] = th.to_dict(orient="records")

# clustering vs. classification evaluation note: tuning improvement summary
hdr("TUNING BEFORE vs AFTER (test set)")
for fam in ("LogReg", "RandForest"):
    a = ev[ev.model.str.startswith(fam + " (default")].iloc[0]; b = ev[~ev.model.str.contains("default") & ev.model.str.startswith(fam)].iloc[0]
    print(f"{fam}: CV AUC {a['CV_ROC_AUC(train)']:.4f} -> {b['CV_ROC_AUC(train)']:.4f} | test AUC {a.roc_auc:.4f} -> {b.roc_auc:.4f} | "
          f"test F1 {a.f1:.4f} -> {b.f1:.4f} | test recall {a.recall:.4f} -> {b.recall:.4f}")

hdr("STEP 9c: EXTRA TUNING DEMO - Decision Tree (defaults overfit, so tuning should matter)")
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import roc_auc_score
dt_base = DecisionTreeClassifier(random_state=RS).fit(Xtr, ytr)
dt_base_cv = cross_val_score(DecisionTreeClassifier(random_state=RS), Xtr, ytr, cv=skf, scoring="roc_auc").mean()
dt_grid = GridSearchCV(DecisionTreeClassifier(random_state=RS), {
    "max_depth": [2, 3, 4, 5, 6, 8, None], "min_samples_leaf": [1, 2, 5, 10], "criterion": ["gini", "entropy"]},
    cv=skf, scoring="roc_auc", n_jobs=-1).fit(Xtr, ytr)
pd.DataFrame(dt_grid.cv_results_)[["param_max_depth", "param_min_samples_leaf", "param_criterion", "mean_test_score", "rank_test_score"]]\
    .round(4).sort_values("rank_test_score").to_csv(f"{RES}/gridsearch_dtree_results.csv", index=False)
dt_rows = []
for name, m, cvs in (("DecTree (default)", dt_base, dt_base_cv), ("DecTree (GridSearch)", dt_grid.best_estimator_, dt_grid.best_score_)):
    pb = m.predict_proba(Xte)[:, 1]; pr = (pb >= 0.5).astype(int)
    dt_rows.append({"model": name, "CV_ROC_AUC(train)": cvs, "train_accuracy": float(m.score(Xtr, ytr)), **classification_report_dict(yte, pr, pb)})
dt_ev = pd.DataFrame(dt_rows).round(4)
print(f"Best params: {dt_grid.best_params_} (56 configs x 5 folds = 280 fits)")
print(dt_ev.to_string(index=False)); dt_ev.to_csv(f"{RES}/dtree_tuning_results.csv", index=False)
R["dtree_tuning"] = {"best_params": {k: (None if v is None else v) for k, v in dt_grid.best_params_.items()}, "table": dt_ev.to_dict(orient="records"),
                     "depth_default": int(dt_base.get_depth()), "depth_tuned": int(dt_grid.best_estimator_.get_depth())}
print(f"Tree depth: default={dt_base.get_depth()} -> tuned={dt_grid.best_estimator_.get_depth()}")

with open(f"{RES}/results.json", "w") as f:
    json.dump(R, f, indent=2, default=lambda o: o.item() if hasattr(o, "item") else str(o))
print("\nSaved results.json, CSV tables and charts.")
