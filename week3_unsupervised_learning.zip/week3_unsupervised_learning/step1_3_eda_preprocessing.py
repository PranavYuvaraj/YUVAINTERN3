"""Steps 1-3: Data understanding, EDA, preprocessing (Wine dataset)."""

import sys, os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))
from preprocessing import load_wine_data, iqr_outlier_counts, standardize

VIS = "outputs/visualizations"
RES = "outputs/results"
pd.set_option("display.width", 160)
pd.set_option("display.max_columns", 30)
sns.set_theme(style="whitegrid")

X, y = load_wine_data()

# ================= STEP 1: DATA UNDERSTANDING =================
print("=" * 70, "\nSTEP 1: DATA UNDERSTANDING\n", "=" * 70, sep="")
print("Shape (rows, features):", X.shape)
print("\nData types:\n", X.dtypes.value_counts().to_string())
print("\nMissing values total:", int(X.isna().sum().sum()),
      "| % missing:", round(X.isna().sum().sum() / X.size * 100, 2))
print("Duplicate rows:", int(X.duplicated().sum()))
print("Categorical features:", int(X.select_dtypes(exclude="number").shape[1]))
print("\nPost-hoc labels (NOT used for training) class counts:")
print(y.value_counts().sort_index().to_string())

# ================= STEP 2: EDA =================
print("\n" + "=" * 70, "\nSTEP 2: EDA\n", "=" * 70, sep="")
desc = X.describe().T
desc["median"] = X.median()
desc["skew"] = X.skew()
desc["range"] = desc["max"] - desc["min"]
desc = desc[["count", "mean", "median", "std", "min", "25%", "75%", "max", "range", "skew"]].round(3)
print(desc.to_string())
desc.to_csv(f"{RES}/eda_summary_statistics.csv")

out_counts = iqr_outlier_counts(X)
print("\nIQR outlier counts per feature (non-zero only):")
print(out_counts[out_counts > 0].sort_values(ascending=False).to_string())
print("Total outlier cells:", int(out_counts.sum()),
      "| rows with >=1 outlier feature:",
      int(((X < (X.quantile(.25) - 1.5*(X.quantile(.75)-X.quantile(.25)))) |
           (X > (X.quantile(.75) + 1.5*(X.quantile(.75)-X.quantile(.25))))).any(axis=1).sum()))

corr = X.corr()
pairs = (corr.where(np.triu(np.ones(corr.shape, dtype=bool), k=1))
         .stack().rename("corr").reset_index())
pairs["abs"] = pairs["corr"].abs()
top = pairs.sort_values("abs", ascending=False).head(8)
print("\nTop 8 feature correlations:")
print(top[["level_0", "level_1", "corr"]].round(3).to_string(index=False))
corr.round(3).to_csv(f"{RES}/correlation_matrix.csv")

# --- Plot 1: histograms
fig, axes = plt.subplots(4, 4, figsize=(16, 12))
for ax, col in zip(axes.ravel(), X.columns):
    sns.histplot(X[col], kde=True, ax=ax, color="steelblue")
    ax.set_title(f"{col}\nskew={X[col].skew():.2f}", fontsize=9)
    ax.set_xlabel("")
for ax in axes.ravel()[len(X.columns):]:
    ax.axis("off")
fig.suptitle("Feature Distributions (Wine dataset, n=178)", fontsize=14)
plt.tight_layout(); plt.savefig(f"{VIS}/01_histograms.png", dpi=110); plt.close()

# --- Plot 2: box plots (standardized so all fit on one axis)
Xs, scaler = standardize(X)
plt.figure(figsize=(13, 6))
sns.boxplot(data=Xs, orient="h", color="lightcoral", fliersize=3)
plt.title("Box Plots of Standardized Features (outliers shown as dots)")
plt.xlabel("Standardized value (z-score)")
plt.tight_layout(); plt.savefig(f"{VIS}/02_boxplots.png", dpi=110); plt.close()

# --- Plot 3: correlation heatmap
plt.figure(figsize=(11, 9))
sns.heatmap(corr, cmap="coolwarm", center=0, annot=True, fmt=".2f", annot_kws={"size": 7})
plt.title("Correlation Heatmap of the 13 Wine Features")
plt.tight_layout(); plt.savefig(f"{VIS}/03_correlation_heatmap.png", dpi=110); plt.close()

# --- Plot 4: scatter / pair plot (labels only for colouring AFTER the fact)
cols = ["flavanoids", "proline", "color_intensity", "alcohol"]
pp_df = X[cols].copy()
pp_df["wine_class (post-hoc only)"] = y.values
g = sns.pairplot(pp_df, hue="wine_class (post-hoc only)", palette="Set1", corner=True,
                 plot_kws={"s": 25, "alpha": 0.8})
g.figure.suptitle("Pair Plot of 4 Key Features (colour = true class, NOT used by clustering)", y=1.02)
g.savefig(f"{VIS}/04_pairplot.png", dpi=100); plt.close("all")

# ================= STEP 3: PREPROCESSING =================
print("\n" + "=" * 70, "\nSTEP 3: PREPROCESSING\n", "=" * 70, sep="")
print("Missing values to impute: 0 | Duplicates to drop: 0 | Encoding needed: none")

before = X.agg(["mean", "std", "min", "max"]).T.round(3)
after = Xs.agg(["mean", "std", "min", "max"]).T.round(3)
cmp_df = pd.concat({"BEFORE": before, "AFTER": after}, axis=1)
print("\nScale comparison before vs after StandardScaler:")
print(cmp_df.to_string())
cmp_df.to_csv(f"{RES}/scale_before_after.csv")

# Worked example 1: z-score of one value
i, f = 0, "proline"
x_val, mu, sd = X.loc[i, f], X[f].mean(), X[f].std(ddof=0)
print(f"\nWORKED EXAMPLE 1 (z-score), sample {i}, feature '{f}':")
print(f"  INPUT  x={x_val}, mean={mu:.3f}, std={sd:.3f}")
print(f"  FORMULA z=(x-mean)/std")
print(f"  CALC   z=({x_val}-{mu:.3f})/{sd:.3f} = {(x_val-mu)/sd:.4f}")
print(f"  OUTPUT sklearn gives {Xs.loc[i, f]:.4f}")

# Worked example 2: why scaling matters for distance-based clustering
a, b = 0, 1
diff = (X.loc[a] - X.loc[b]) ** 2
share = (diff / diff.sum() * 100).sort_values(ascending=False)
print(f"\nWORKED EXAMPLE 2 (Euclidean distance between sample {a} and {b}):")
print(f"  RAW distance    = {np.sqrt(diff.sum()):.3f}")
print(f"  Share of squared distance from top feature: {share.index[0]} = {share.iloc[0]:.2f}%")
print(f"  Share from 'proline' alone = {share['proline']:.2f}%")
diff_s = (Xs.loc[a] - Xs.loc[b]) ** 2
share_s = (diff_s / diff_s.sum() * 100).sort_values(ascending=False)
print(f"  SCALED distance = {np.sqrt(diff_s.sum()):.3f}")
print(f"  Top feature after scaling: {share_s.index[0]} = {share_s.iloc[0]:.2f}%")
print(f"  Share from 'proline' after scaling = {share_s['proline']:.2f}%")

# Plot 5: before vs after scale
fig, ax = plt.subplots(1, 2, figsize=(14, 5))
X.std().sort_values().plot.barh(ax=ax[0], color="darkorange", logx=True)
ax[0].set_title("Std Dev per feature BEFORE scaling (log axis)")
Xs.std().sort_values().plot.barh(ax=ax[1], color="seagreen")
ax[1].set_title("Std Dev per feature AFTER scaling")
plt.tight_layout(); plt.savefig(f"{VIS}/05_scale_before_after.png", dpi=110); plt.close()

# Save cleaned/scaled data for later steps
X.to_csv("data/wine_features.csv", index=False)
Xs.to_csv("data/wine_features_scaled.csv", index=False)
y.to_csv("data/wine_labels_posthoc.csv", index=False)
print("\nSaved scaled data + 5 charts + CSV summaries.")
